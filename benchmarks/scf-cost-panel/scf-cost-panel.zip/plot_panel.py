"""Plot the seven-system timing panel using matplotlib and the published JSON results."""
import argparse
import json
import math
from pathlib import Path
from statistics import median

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator


POLICIES = (
    ("direct40", "Direct A"),
    ("direct_low", "Direct B"),
    ("direct80", "Direct A, 80-step cap"),
    ("blind_lower", "A → B if unconverged"),
    ("blind_extend", "A → 80 steps if unconverged"),
    ("triage", "A → triage-selected retry"),
    ("full_A_plus_B", "A and B on every system"),
)
SYSTEMS = (
    ("si-diamond", "Si · diamond"),
    ("al-fcc", "Al · fcc"),
    ("na-bcc", "Na · bcc"),
    ("fe-bcc", "Fe · bcc, magnetic"),
    ("mgo-rs", "MgO · rocksalt"),
    ("al111-stress", "Al(111) · known stress"),
    ("na110-slab", "Na(110) · held-out stress"),
)

INK, MUTED, GRID = "#192c38", "#4b6170", "#d4dee2"
A, B, FOCUS, FAILED = "#27619b", "#087f70", "#72428a", "#ad3e1c"


def draw(summary, details, output):
    rounds = sorted(summary["rounds"], key=lambda row: row["round"])
    supplement = {row["round"]: row["full_A_plus_B"] for row in details["rounds"]}
    if [r["round"] for r in rounds] != [1, 2, 3] or set(summary["cases"]) != dict(SYSTEMS).keys():
        raise ValueError("Expected the complete three-round, seven-system panel")
    nrounds = len(rounds)
    times = {}
    counts = {}
    for key, _ in POLICIES:
        full = key == "full_A_plus_B"
        records = [supplement[r["round"]] if full else r["policies"][key] for r in rounds]
        times[key] = [r["elapsed_s" if full else "total_s"] for r in records]
        counts[key] = [r["complete"] for r in records]

    plt.rcParams.update({"font.family": "DejaVu Sans", "axes.edgecolor": GRID,
                         "xtick.color": MUTED, "text.color": INK, "font.size": 10})
    fig = plt.figure(figsize=(15, 6.65), facecolor="white")
    # Axes share row centers. The numeric columns sit outside the plotting axes.
    bottom, height = 0.225, 0.50
    cost = fig.add_axes((0.196, bottom, 0.184, height))
    scf = fig.add_axes((0.765, bottom, 0.205, height))
    for ax in (cost, scf):
        ax.set_ylim(6.5, -0.5)
        ax.set_yticks([])
        ax.spines[["left", "right", "top"]].set_visible(False)
        ax.tick_params(axis="x", length=3, labelsize=9, pad=3)
        ax.grid(axis="x", color=GRID, linewidth=.6, zorder=0)
        ax.set_axisbelow(True)
    def row_y(i):
        return bottom + height * (6.5 - i) / 7
    def txt(x, y, label, **opts):
        fig.text(x, y, label, va="center", **opts)
    def rule(x1, x2, y):
        fig.add_artist(Line2D((x1, x2), (y, y), transform=fig.transFigure, color=GRID, lw=.8))
    def header(x, s):
        txt(x, .748, s, fontsize=9.2, fontweight="bold", color=MUTED)

    txt(.035, .936, "SCF intervention costs across seven systems", fontsize=23, fontweight="bold")
    txt(.035, .883, "Quantum ESPRESSO 7.5   ·   Three paired cold-start rounds   ·   One MPI rank and one thread",
        fontsize=11.2, color=MUTED)
    rule(.035, .972, .842)
    txt(.035, .796, "a   End-to-end wall time", fontsize=15, fontweight="bold")
    txt(.608, .796, "b   Electronic iterations by system", fontsize=15, fontweight="bold")
    header(.035, "Policy")
    header(.395, "Median [min–max], s")
    header(.527, "Completed")
    header(.608, "System")
    for x, color, label in ((.765, A, "A   β = 0.70"), (.866, B, "B   β = 0.20")):
        fig.add_artist(Line2D([x], [.748], marker="o" if color == A else "s", markersize=6,
                              linewidth=0, color=color, transform=fig.transFigure))
        txt(x+.009, .748, label, fontsize=9.7, color=color)
    maximum = max(max(t) for t in times.values())
    step = 20 if maximum <= 200 else 50
    cost.set_xlim(0, step * math.ceil(maximum / step))
    cost.xaxis.set_major_locator(MaxNLocator(nbins=4, integer=True))
    for i, (key, label) in enumerate(POLICIES):
        values = times[key]
        lo, mid, hi = min(values), median(values), max(values)
        focus = key == "triage"
        color = FOCUS if focus else "#688695"
        if focus:
            fig.add_artist(plt.Rectangle((.032, row_y(i)-.026), .552, .052, transform=fig.transFigure,
                                         fc="#f5eff8", ec="none", zorder=-1))
        cost.barh(i, mid, height=.32, color=color, alpha=.85, zorder=2)
        cost.errorbar(mid, i, xerr=[[mid-lo], [hi-mid]], color=INK, capsize=3.5, lw=1.1, zorder=3)
        weight = "bold" if focus else "normal"
        txt(.035, row_y(i), label, fontsize=10.1, fontweight=weight, color=FOCUS if focus else INK)
        txt(.395, row_y(i), f"{mid:.1f}  [{lo:.1f}–{hi:.1f}]", fontsize=9.6,
            fontvariant="normal", fontweight=weight)
        c = counts[key]
        completed = f"{c[0]}/7" if len(set(c)) == 1 else f"{min(c)}–{max(c)}/7"
        txt(.547, row_y(i), completed, ha="center", fontsize=10.1, fontweight=weight)
    cost.set_facecolor("none")
    cost.set_xlabel("Wall time per round (s)", color=MUTED, fontsize=10, labelpad=5)

    scf.set_xlim(0, 44)
    scf.set_xticks(range(0, 41, 10))
    for i, (case, label) in enumerate(SYSTEMS):
        txt(.608, row_y(i), label, fontsize=10.2)
        for arm, dy, color, marker in (("A", -.17, A, "o"), ("B", .17, B, "s")):
            data = summary["cases"][case]["arms"][arm]
            steps = data["steps"]
            if len(steps) != nrounds or any(n is None for n in steps):
                raise ValueError(f"Incomplete iteration series for {case}/{arm}")
            mid = median(steps)
            number = f"{mid:g}" if min(steps) == max(steps) else f"{mid:g} [{min(steps)}–{max(steps)}]"
            if data["accepted"] != nrounds:
                marker, color = "X", FAILED
                if data["accepted"]:
                    number += f" ({data['accepted']}/{nrounds} converged)"
            scf.scatter(mid, i+dy, s=54, color=color, marker=marker, linewidths=.5,
                        edgecolors="white", zorder=3)
            scf.annotate(number, (mid, i+dy), xytext=(6, 0), textcoords="offset points",
                         ha="left", va="center", fontsize=9.1, color=color, fontweight="bold")
    scf.set_xlabel("SCF iterations (40-step cap for A and B)", fontsize=10, color=MUTED, labelpad=5)
    fig.add_artist(Line2D((.59,.59), (.212,.814), transform=fig.transFigure, color=GRID, lw=.8))
    rule(.035, .972, .142)
    txt(.035, .106, "A and B use a 40-step cap unless specified. All retries start from scratch. Triage includes CLI time.",
        color=MUTED, fontsize=9.4)
    txt(.035, .071, "Direct A at 80 steps reuses the measured A time for systems that already converged by step 40.",
        color=MUTED, fontsize=9.4)
    fig.add_artist(Line2D([.612], [.106], marker="X", markersize=7, color=FAILED,
                          transform=fig.transFigure, linewidth=0))
    txt(.621, .106, "Reached the cap without convergence.", color=FAILED, fontsize=9.4)
    txt(.608, .071, "Both slab stress tests use a two-vector mixing history.", color=MUTED, fontsize=9.4)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=180, metadata={"Title": "SCF intervention costs across seven systems"})
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=Path(__file__).resolve().parent / "results")
    parser.add_argument("--output", type=Path, default=Path("scf-cost-panel.png"))
    args = parser.parse_args()
    summary = json.loads((args.results / "panel-summary.json").read_text())
    details = json.loads((args.results / "cost-details.json").read_text())
    draw(summary, details, args.output)


if __name__ == "__main__":
    main()
