"""Post-protocol opportunity-cost ledger. Reads archived measurements; launches no processes."""
import argparse
import json
import math
from pathlib import Path
import statistics

INCIDENTS = {"si-short-budget", "fe-missing-upf"}
ROUNDS = (1, 2, 3)


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def timing_index(panel, cases):
    records = {}
    for path in sorted((panel / "measured").glob("*/r*/*/timing.json")):
        row = load(path)
        case, rep, arm = row["case"], row["round"], row["arm"]
        if (case not in cases | INCIDENTS or rep not in ROUNDS or arm not in {"A", "B", "E"}
                or path != panel / "measured" / case / f"r{rep}" / arm / "timing.json"):
            raise ValueError(f"Unexpected timing record: {path}")
        if not math.isfinite(row["elapsed_s"]) or row["elapsed_s"] <= 0 or type(row["accepted"]) is not bool:
            raise ValueError(f"Invalid measured time or acceptance: {path}")
        records[case, rep, arm] = row
    for case in cases | INCIDENTS:
        expected = {"A", "B"}
        if case in cases and any(not records[case, i, "A"]["accepted"] for i in ROUNDS):
            expected.add("E")
        for i in ROUNDS:
            if {a for c, r, a in records if c == case and r == i} != expected:
                raise ValueError(f"Incomplete or unexpected arms: {case}/r{i}")
    return records


def spent(rows):
    return {"launches": len(rows), "elapsed_s": math.fsum(row["elapsed_s"] for row in rows)}


def single_latency(batches):
    samples = [s for b in batches for s in b["samples_s"]]
    if not samples:
        return None
    if any(not math.isfinite(s) or s <= 0 for s in samples):
        raise ValueError("Invalid single-log latency")
    medians = [statistics.median(b["samples_s"]) for b in batches if b["samples_s"]]
    return dict(logs=len(medians), calls=len(samples), min_s=min(samples), median_s=statistics.median(samples),
                max_s=max(samples), min_per_log_median_s=min(medians), max_per_log_median_s=max(medians))


def detail(panel):
    summary = load(panel / "results/panel-summary.json")
    overhead = load(panel / "results/cli-overhead.json")
    cases = set(summary["cases"])
    if len(cases) != 7 or cases & INCIDENTS:
        raise ValueError("Expected seven physical cases")
    timings = timing_index(panel, cases)
    policy_rounds = {row["round"]: row["policies"] for row in summary["rounds"]}
    incidents = {row["round"]: row for row in summary["incidents"]}
    clocks = {row["round"]: row for row in overhead["rounds"]}
    physical = [r for r in timings.values() if r["case"] in cases]
    faults = [r for r in timings.values() if r["case"] in INCIDENTS]
    comparisons, all_singles, cli_times = [], [], []
    for rep in ROUNDS:
        policies = policy_rounds[rep]
        triage = policies["triage"]
        pair = [timings[case, rep, arm] for case in sorted(cases) for arm in ("A", "B")]
        full = spent(pair)
        full["complete"] = sum(any(timings[case, rep, arm]["accepted"] for arm in ("A", "B")) for case in cases)
        cheapest = {}
        for case in sorted(cases):
            successes = [r for r in physical if r["round"] == rep and r["case"] == case and r["accepted"]]
            if successes:
                best = min(successes, key=lambda r: (r["elapsed_s"], r["arm"]))
                cheapest[case] = {"arm": best["arm"], "elapsed_s": best["elapsed_s"]}
        oracle = {"complete": len(cheapest), "by_case": cheapest,
                  "all_cases_elapsed_s": math.fsum(r["elapsed_s"] for r in cheapest.values()) if len(cheapest) == len(cases) else None}
        groups = clocks[rep]
        singles = groups["single_log"]
        all_singles.extend(singles)
        for b in [groups[k] for k in ("primary", "retry", "incident", "repair")] + singles:
            cli_times.extend(b["samples_s"])
        fault_round = incidents[rep]
        triage_s = triage["total_s"]
        delta = {p: triage_s - policies[p]["total_s"] for p in ("direct40", "blind_lower", "blind_extend", "direct80", "direct_low")}
        all_paid = {group: spent([r for r in values if r["round"] == rep])
                    for group, values in (("physical", physical), ("incidents", faults))}
        comparisons.append(dict(round=rep, physical_tasks=len(cases), paid_solver=all_paid,
                                full_A_plus_B=full, conditional_triage=triage,
                                full_A_plus_B_minus_triage_s=full["elapsed_s"] - triage_s,
                                triage_minus_comparator_s=delta,
                                comparator_completions={p: policies[p]["complete"] for p in delta},
                                incident_targeted_minus_blind_then_repair_s=fault_round["targeted_s"] - fault_round["blind_then_repair_s"],
                                hindsight_fastest_successful_measured_arm=oracle, single_log_cli=single_latency(singles)))
    solver_s = spent(list(timings.values()))
    metering = dict(timed_cli_launches=len(cli_times), timed_cli_elapsed_s=math.fsum(cli_times),
                    solver_plus_timed_cli_elapsed_s=solver_s["elapsed_s"] + math.fsum(cli_times))
    return dict(scope="Post-protocol descriptive comparisons, three paired rounds. Seconds are serial process wall time.",
                interpretation=[
                    "Full A+B pays for two complete or capped cold runs per case, retaining any accepted result. No third production run or CLI is charged. Short probes were not measured.",
                    "The hindsight benchmark picks the fastest accepted measured A, B or E separately for each case and round. The selection uses outcomes and times unavailable before launch.",
                    "A positive signed difference means the first named policy costs more. Compare completions before interpreting any time difference.",
                    "Paid solver time counts every launch once. Incident policy replays borrow the matched normal material A for repair, already counted in physical launches.",
                    "Paid CLI time sums all repeated timed CLI child invocations including stand-alone latency controls. Version checks, Python audit, human time and queue time are outside this ledger.",
                ],
                paid_solver=dict(physical=spent(physical), incidents=spent(faults), all=solver_s),
                paid_metering=metering, observed_single_log_cli=single_latency(all_singles), rounds=comparisons)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--panel", type=Path, default=Path(__file__).resolve().parent)
    p.add_argument("--output", type=Path, help="default: results/cost-details.json in the panel")
    args = p.parse_args()
    data = detail(args.panel)
    output = args.output or (args.panel / "results/cost-details.json")
    output.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"paid_solver": data["paid_solver"], "paid_metering": data["paid_metering"],
                      "A_plus_B_minus_triage_s": [r["full_A_plus_B_minus_triage_s"] for r in data["rounds"]]}))


if __name__ == "__main__":
    main()
