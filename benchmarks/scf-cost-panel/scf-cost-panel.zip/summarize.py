"""Reconstruct terminal policies from paired QE measurements, charging every attempted run."""
import argparse
import json
import statistics
from pathlib import Path

CASES = ["si-diamond", "al-fcc", "na-bcc", "fe-bcc", "mgo-rs", "al111-stress", "na110-slab"]
KNOWN = {"si-diamond", "al111-stress"}
POLICIES = ("direct40", "blind_lower", "blind_extend", "triage", "direct80", "direct_low")


def read(results, case, rep, arm):
    row = json.loads((results / case / f"r{rep}" / arm / "timing.json").read_text())
    if (row["case"], row["round"], row["arm"]) != (case, rep, arm):
        raise ValueError(f"Inconsistent timing record {case} {rep} {arm}")
    return row


def retry_for(code):
    if code == "repeated_rebounds":
        return "B"
    if code in {"improving_at_limit", "short_iteration_budget"}:
        return "E"
    return None


def replay(arms, policy):
    a = arms["A"]
    visits = [a]
    if policy == "direct_low":
        visits = [arms["B"]]
    elif policy == "direct80":
        visits = [arms.get("E", a)]
    elif not a["accepted"] and policy != "direct40" and a["status"] == "unconverged":
        followup = {"blind_lower": "B", "blind_extend": "E", "triage": retry_for(a["code"])}[policy]
        if followup:
            visits.append(arms[followup])
    final = visits[-1]
    return dict(attempts=[row["arm"] for row in visits],
                solver_s=sum(row["elapsed_s"] for row in visits),
                accepted=final["accepted"], final_code=final["code"],
                needs_review=not final["accepted"] or final["priority"] != "none")


def group(rows, overhead=0):
    solver = sum(row["solver_s"] for row in rows)
    return dict(tasks=len(rows), complete=sum(row["accepted"] for row in rows),
                manual_review=sum(row["needs_review"] for row in rows),
                launches=sum(len(row["attempts"]) for row in rows),
                solver_s=solver, cli_s=overhead, total_s=solver+overhead)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--overheads", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    clocks = {r["round"]: r for r in json.loads(args.overheads.read_text())["rounds"]}
    rounds, incident_rounds = [], []
    samples = {case: {} for case in CASES}
    for rep in (1, 2, 3):
        decisions = {}
        for case in CASES:
            arms = {arm: read(args.results, case, rep, arm) for arm in ("A","B")}
            if (args.results / case / f"r{rep}" / "E" / "timing.json").exists():
                arms["E"] = read(args.results, case, rep, "E")
            for arm, record in arms.items():
                samples[case].setdefault(arm, []).append(record)
            decisions[case] = {policy: replay(arms, policy) for policy in POLICIES}
        totals, holdout = {}, {}
        for policy in POLICIES:
            cli = (clocks[rep]["primary"]["median_s"] + clocks[rep]["retry"]["median_s"]) if policy == "triage" else 0.0
            totals[policy] = group([decisions[c][policy] for c in CASES], cli)
            # Subsets share the same measured seven-job CLI calls. Report solver time only for them.
            holdout[policy] = group([decisions[c][policy] for c in CASES if c not in KNOWN])
        rounds.append(dict(round=rep, policies=totals, holdout_solver_only=holdout, paths=decisions))

        incident_cases = {}
        for case, repaired in [("si-short-budget", "si-diamond"), ("fe-missing-upf","fe-bcc")]:
            error = read(args.results, case, rep, "A")
            blind = read(args.results, case, rep, "B")
            repair = read(args.results, repaired, rep, "A")
            expected = {"si-short-budget":"short_iteration_budget","fe-missing-upf":"pseudopotential_error"}[case]
            targeted = [error, repair] if error["code"] == expected and not error["accepted"] else [error]
            blind_path = [error]
            if not error["accepted"]:
                blind_path.append(blind)
                if not blind["accepted"]:
                    blind_path.append(repair)
            incident_cases[case] = dict(code=error["code"], targeted_accepted=targeted[-1]["accepted"],
                                        blind_then_repair_accepted=blind_path[-1]["accepted"],
                                        targeted_solver_s=sum(x["elapsed_s"] for x in targeted),
                                        blind_then_repair_solver_s=sum(x["elapsed_s"] for x in blind_path),
                                        blind_retry_s=blind["elapsed_s"], repair_source=repaired)
        diagnostic_s = clocks[rep]["incident"]["median_s"] + clocks[rep]["repair"]["median_s"]
        target_total = diagnostic_s + sum(x["targeted_solver_s"] for x in incident_cases.values())
        blind_total = sum(x["blind_then_repair_solver_s"] for x in incident_cases.values())
        incident_rounds.append(dict(round=rep, cases=incident_cases, targeted_cli_s=diagnostic_s,
                                    targeted_s=target_total, blind_then_repair_s=blind_total,
                                    net_saved_s=blind_total-target_total))

    cases = {}
    for case, arms in samples.items():
        energy_diffs, moment_diffs = [], []
        for i in range(3):
            equivalent = [records[i] for records in arms.values() if records[i]["accepted"]]
            if len(equivalent) >= 2:
                energies = [r["energy_ry"] for r in equivalent]
                energy_diffs.append(max(energies)-min(energies))
                moments = [r["magnetization_bohr"] for r in equivalent if r["magnetization_bohr"] is not None]
                if len(moments) >= 2:
                    moment_diffs.append(max(moments)-min(moments))
        cases[case] = {"known": case in KNOWN, "arms": {}, "max_paired_energy_spread_ry": max(energy_diffs,default=None),
                       "max_paired_magnetization_spread_bohr": max(moment_diffs,default=None)}
        for arm, records in arms.items():
            elapsed = [r["elapsed_s"] for r in records]
            cases[case]["arms"][arm] = dict(accepted=sum(r["accepted"] for r in records),
                    steps=[r["iterations"] for r in records], codes=[r["code"] for r in records],
                    median_s=statistics.median(elapsed), wall_s=elapsed)
    report = dict(software="qe-scf-slim v0.4.0", repetitions=3, cases=cases, rounds=rounds, incidents=incident_rounds)
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False)+"\n")


if __name__ == "__main__":
    main()
