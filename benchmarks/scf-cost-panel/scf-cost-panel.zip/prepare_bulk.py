from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
definitions = [
 ("fe-bcc", "Ferromagnetic bcc Fe", 3, 2.866, 72, 576,
  [('Fe', 55.845, "Fe.pbe-spn-kjpaw_psl.1.0.0.UPF", "0.0 0.0 0.0")],
  "a=2.866 angstrom and starting magnetization of 0.60 from repo Fe_bcc_scf.in; rebuilt as a single-atom bcc primitive cell.", True),
 ("mgo-rs", "Rocksalt MgO", 2, 4.212, 60, 480,
  [('Mg', 24.305, "Mg.pbe-spnl-kjpaw_psl.1.0.0.UPF", "0.0 0.0 0.0"),
   ('O', 15.999, "O.pbe-n-kjpaw_psl.1.0.0.UPF", "0.5 0.5 0.5")],
  "a=4.212 angstrom from repo MgO_rs_scf.in; rebuilt as an fcc primitive cell with a two-atom rocksalt basis.", False),
 ("na-bcc", "Bulk bcc Na", 3, 4.23, 70, 560,
  [('Na', 22.990, "Na.pbe-spn-kjpaw_psl.1.0.0.UPF", "0.0 0.0 0.0")],
  "Ideal monatomic bcc primitive cell with representative conventional cubic lattice parameter 4.23 angstrom, fixed before calculation.", True),
]

for slug,name,ibrav,lattice,wfc,rho,species,provenance,metallic in definitions:
    dest = ROOT/'cases'/slug
    extra = ["occupations='fixed'"]
    if metallic:
        extra = ["occupations='smearing'", "smearing='mv'", "degauss=0.02"]
    if slug == "fe-bcc":
        extra += ["nspin=2", "starting_magnetization(1)=0.60"]
    lines = ["&CONTROL", " calculation='scf'", f" prefix='{slug}'", " pseudo_dir='./pseudos'", " outdir='./scratch'", " disk_io='none'", "/", "&SYSTEM",
             f" ibrav={ibrav}", f" A={lattice}", f" nat={len(species)}", f" ntyp={len(species)}", f" ecutwfc={wfc}", f" ecutrho={rho}"]+[" "+x for x in extra]+[
             "/", "&ELECTRONS", " conv_thr=1.0d-8", " electron_maxstep=40", " mixing_mode='plain'", " mixing_ndim=8", " mixing_beta=0.70", " startingpot='atomic'", " startingwfc='atomic'", "/", "ATOMIC_SPECIES"]
    lines += [f"{e} {mass} {file}" for e,mass,file,_ in species]
    lines += ["ATOMIC_POSITIONS crystal"]+[f"{e} {coords}" for e,_,_,coords in species]+["K_POINTS automatic","4 4 4 0 0 0"]
    raw = '\n'.join(lines)+'\n'
    (dest/'base.in').write_text(raw)
    pseudos=[]
    for e,_,filename,_ in species:
        data=(ROOT/'pseudos'/filename).read_bytes()
        if not data.rstrip().endswith(b'</UPF>'):
            continue
        head=data[:1200].decode()
        cuts=[float(n) for n in re.findall(r'Suggested minimum cutoff for (?:wavefunctions|charge density):\s*([0-9.]+)\s*Ry',head)]
        assert len(cuts)==2 and wfc>=cuts[0] and rho>=cuts[1]
        pseudos.append(dict(element=e,file=filename,url="https://pseudopotentials.quantum-espresso.org/upf_files/"+filename,source_table="https://pseudopotentials.quantum-espresso.org/legacy_tables/ps-library/"+e.lower(),sha256=hashlib.sha256(data).hexdigest(),type="PBE scalar-relativistic PAW, PS Library 1.0.0",suggested_minimum_ecutwfc_ry=cuts[0],suggested_minimum_ecutrho_ry=cuts[1]))
    if len(pseudos)==len(species):
        metadata=dict(id=slug,name=name,role='held-out bulk material',structure=provenance,provenance=provenance,calculation="SCF, QE primitive lattice ibrav="+str(ibrav),lattice_parameter_angstrom=lattice,atoms=len(species),kpoints="4x4x4, no shift",ecutwfc_ry=wfc,ecutrho_ry=rho,occupations=extra,conv_thr_ry=1e-8,electron_maxstep=40,mixing_mode="plain",mixing_ndim=8,mixing_beta=0.70,initialization="cold atomic potential and wavefunctions",resources="single MPI rank and thread",input_sha256=hashlib.sha256(raw.encode()).hexdigest(),pseudopotentials=pseudos,caveat="Fixed small primitive cell and modest unshifted mesh are for electronic SCF timing only. No cutoff, k-point, magnetic-state, or observable convergence study.")
        (dest/'case.json').write_text(json.dumps(metadata,indent=2)+'\n')
