"""Build or independently verify the portable evidence ZIP for the frozen seven-case panel."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tempfile
import zipfile

CASES = ("si-diamond", "al-fcc", "fe-bcc", "na-bcc", "mgo-rs", "al111-stress", "na110-slab")
INCIDENTS = ("fe-missing-upf", "si-short-budget")
ARTIFACTS = ("pw.in", "pw.out", "pw.err", "timing.json")
SUMMARY_EXTS = {".json", ".csv", ".tsv", ".md", ".txt", ".py"}
MANIFEST = "manifest.json"
# Reject personal and machine-specific paths in the selected text payload, including JSON escapes.
HOST_PATH = re.compile(rb"/(?:Users|home|private/var|var/folders|opt/homebrew)/|[A-Za-z]:[\\/]+Users[\\/]", re.I)


def require(ok, why):
    if not ok:
        raise ValueError(why)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def as_json(data):
    return (json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()


def public_name(name):
    parts = name.split("/")
    if not all(re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9._-]*", part) for part in parts):
        return False
    path = PurePosixPath(name)
    if len(parts) == 3 and parts[0] == "cases":
        return parts[1] in CASES and parts[2] in {"base.in", "case.json"}
    if len(parts) == 5 and parts[0] == "measured":
        return (parts[1] in CASES + INCIDENTS and parts[2] in {"r1", "r2", "r3"}
                and parts[3] in {"A", "B", "E"} and parts[4] in ARTIFACTS)
    if len(parts) == 1:
        return path.suffix in {".py", ".md"}
    return (len(parts) == 2 and parts[0] in {"audit", "results"}
            and path.stem not in {"partial", "precheck"} and path.suffix in SUMMARY_EXTS)


def path_in(panel, name):
    require(public_name(name), f"Outside evidence contract: {name}")
    path = panel
    for part in PurePosixPath(name).parts:
        path = path / part
        require(not path.is_symlink(), f"Selected symlink: {name}")
    require(path.is_file(), f"Missing required evidence: {name}")
    return path


def collect(panel, extras):
    names = {"protocol.md", "run_panel.py", "pack_evidence.py", *extras}
    for folder in [panel, panel / "audit", panel / "results"]:
        require(not folder.is_symlink(), f"Symlink directory: {folder.name}")
        if folder.is_dir():
            for item in folder.iterdir():
                name = item.relative_to(panel).as_posix()
                if public_name(name):
                    names.add(name)
    cases = CASES + INCIDENTS
    for case in cases:
        if case in CASES:
            names.update(f"cases/{case}/{file}" for file in ("case.json", "base.in"))
        for rep in (1, 2, 3):
            prefix = f"measured/{case}/r{rep}"
            for arm in ("A", "B", "E"):
                folder = panel / prefix / arm
                if arm != "E" or folder.exists() or folder.is_symlink():
                    names.update(f"{prefix}/{arm}/{file}" for file in ARTIFACTS)
    return {name: path_in(panel, name).read_bytes() for name in sorted(names)}


def validate(files):
    require({"protocol.md", "run_panel.py", "pack_evidence.py"} <= files.keys(), "Missing protocol or scripts")
    for name, data in files.items():
        require(public_name(name), f"Unexpected member: {name}")
        require(not HOST_PATH.search(data), f"Machine-local path in {name}")
    rows = {}
    for case in CASES + INCIDENTS:
        if case in CASES:
            metadata = json.loads(files[f"cases/{case}/case.json"])
            require(metadata["id"] == case, f"Wrong case id: {case}")
            base = digest(files[f"cases/{case}/base.in"])
            require(metadata.get("input_sha256", base) == base, f"Base input hash mismatch: {case}")
        for rep in (1, 2, 3):
            for arm in ("A", "B", "E"):
                prefix = f"measured/{case}/r{rep}/{arm}/"
                selected = [name for name in files if name.startswith(prefix)]
                if arm == "E" and not selected:
                    continue
                require(set(selected) == {prefix + name for name in ARTIFACTS}, f"Incomplete run: {prefix}")
                row = json.loads(files[prefix + "timing.json"])
                require((row["case"], row["round"], row["arm"]) == (case, rep, arm), f"Wrong identity: {prefix}")
                require(type(row["accepted"]) is bool and math.isfinite(row["elapsed_s"]) and row["elapsed_s"] > 0,
                        f"Invalid acceptance/time: {prefix}")
                nlines = len(files[prefix + "pw.out"].splitlines())
                require(all(isinstance(n, int) and 1 <= n <= nlines for n in row["evidence_lines"]),
                        f"Evidence line out of range: {prefix}")
                rows[case, rep, arm] = row
        extension = case in CASES and any(not rows[case, i, "A"]["accepted"] for i in (1, 2, 3))
        require(all(((case, i, "E") in rows) == extension for i in (1, 2, 3)), f"Wrong extension coverage: {case}")
    checks = {"run_count": len(rows), "audit_log_hashes": 0, "timing_summaries": 0}
    for name, data in files.items():
        if not name.startswith(("audit/", "results/")) or not name.endswith(".json"):
            continue
        obj = json.loads(data)
        if not isinstance(obj, dict):
            continue
        if isinstance(obj.get("input_sources"), dict):
            for case, source in obj["input_sources"].items():
                base_hash = digest(files[f"cases/{case}/base.in"])
                require(source["base_sha256"] == base_hash, f"{name}: {case} audit input hash mismatch")
        logs = list(obj.get("logs", []))
        if "episodes" in obj and "issues" in obj:
            incident_keys = set()
            for episode in obj["episodes"]:
                case, rep = episode["incident"], episode["round"]
                require(case in INCIDENTS and rep in {1, 2, 3}, f"{name}: unknown incident episode")
                for arm in ("A", "B"):
                    log = episode["launches"][arm]
                    key = f"{case}/r{rep}/{arm}/pw.out"
                    require(log["path"] == key and key not in incident_keys, f"{name}: incorrect incident log key")
                    timed = rows[case, rep, arm]
                    require(log["time_s"] == timed["elapsed_s"] and log["decision"] == timed["code"],
                            f"{name}: incorrect incident outcome for {key}")
                    incident_keys.add(key)
                    logs.append(log)
            require(len(incident_keys) == len(INCIDENTS) * 3 * 2, f"{name}: incomplete incident audit")
        audited = set()
        for log in logs:
            if not isinstance(log, dict) or "sha256" not in log:
                continue
            key = PurePosixPath(log["path"])
            if key.parts[:1] != ("measured",):
                key = PurePosixPath("measured") / key
            key = str(key)
            require(key in files and key.endswith("/pw.out") and key not in audited, f"{name}: invalid log key {key}")
            require(digest(files[key]) == log["sha256"], f"{name}: raw log hash mismatch: {key}")
            audited.add(key)
        if "input_sources" in obj and "n_logs" in obj:
            expected = {f"measured/{c}/r{i}/{a}/pw.out" for c,i,a in rows if c in CASES}
            require(expected == audited and len(audited) == obj["n_logs"], f"{name}: incomplete physical audit")
        checks["audit_log_hashes"] += len(audited)
        if obj.get("repetitions") == 3 and isinstance(obj.get("cases"), dict):
            require(set(CASES) == set(obj["cases"]), f"{name}: wrong physical cases")
            for case, summary in obj["cases"].items():
                expected_arms = {a for c, _, a in rows if c == case}
                require(expected_arms == set(summary["arms"]), f"{name}: wrong arms for {case}")
                for arm, s in summary["arms"].items():
                    runs = [rows[case, i, arm] for i in (1, 2, 3)]
                    require(s["wall_s"] == [r["elapsed_s"] for r in runs] and s["steps"] == [r["iterations"] for r in runs]
                            and s["codes"] == [r["code"] for r in runs] and s["accepted"] == sum(r["accepted"] for r in runs),
                            f"{name}: summary differs from timing records for {case}/{arm}")
            checks["timing_summaries"] += 1
    return checks


def manifest(files):
    return {"schema": 1, "checks": validate(files),
            "files": {name: {"size": len(data), "sha256": digest(data)} for name, data in sorted(files.items())}}


def verify(path):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        require(names == sorted(set(names)) and MANIFEST in names, "ZIP names unsorted, duplicated, or manifest missing")
        for item in z.infolist():
            require(stat.S_ISREG(item.external_attr >> 16), f"Non-regular member: {item.filename}")
        raw_manifest = z.read(MANIFEST)
        files = {name: z.read(name) for name in names if name != MANIFEST}
        expected = manifest(files)
        require(raw_manifest == as_json(expected), "Manifest does not match archive payload")
    return expected["checks"]


def write(panel, output, extras):
    files = collect(panel, extras)
    require(output.suffix.lower() == ".zip", "Output name must end in .zip")
    files[MANIFEST] = as_json(manifest(files))
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(dir=output.parent, suffix=".zip")
    os.close(fd)
    try:
        with zipfile.ZipFile(temp, "w") as z:
            for name in sorted(files):
                info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                z.writestr(info, files[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        checks = verify(temp)
        os.replace(temp, output)
        return checks
    finally:
        Path(temp).unlink(missing_ok=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    action = p.add_mutually_exclusive_group(required=True)
    action.add_argument("--output", type=Path, help="build an evidence ZIP")
    action.add_argument("--verify", type=Path, metavar="ZIP", help="verify without extracting")
    p.add_argument("--panel", type=Path, default=Path(__file__).resolve().parent)
    p.add_argument("--include", action="append", default=[], metavar="RELATIVE_NAME",
                   help="require an eligible report/script to be present (repeatable)")
    args = p.parse_args()
    path = args.verify or args.output
    try:
        checks = verify(path) if args.verify else write(args.panel, path, args.include)
    except (ValueError, OSError, KeyError, zipfile.BadZipFile) as exc:
        p.exit(1, f"Evidence check failed: {exc}\n")
    print(f"{path.name}  sha256={digest(path.read_bytes())}  {json.dumps(checks, sort_keys=True)}")


if __name__ == "__main__":
    main()
