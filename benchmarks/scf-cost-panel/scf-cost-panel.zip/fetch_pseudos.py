"""Fetch or verify the Quantum ESPRESSO pseudopotentials pinned in cases/*/case.json."""
import argparse
import hashlib
import json
from pathlib import Path
import re
from tempfile import NamedTemporaryFile
from urllib.request import urlopen

HERE = Path(__file__).resolve().parent
QE_UPF_URL = "https://pseudopotentials.quantum-espresso.org/upf_files/"


def pinned_files(cases):
    files = {}
    for manifest in sorted(cases.glob("*/case.json")):
        for entry in json.loads(manifest.read_text())["pseudopotentials"]:
            name, url, sha = (entry[key] for key in ("file", "url", "sha256"))
            if not re.fullmatch(r"[\w.-]+\.UPF", name, flags=re.ASCII) or url != QE_UPF_URL + name:
                raise ValueError(f"Unexpected QE filename or URL in {manifest}: {name!r}, {url!r}")
            if not re.fullmatch(r"[a-f0-9]{64}", sha):
                raise ValueError(f"Invalid SHA-256 in {manifest}: {name}")
            if name in files and files[name] != (url, sha):
                raise ValueError(f"Conflicting pins for {name} in {manifest}")
            files[name] = (url, sha)
    if not files:
        raise ValueError(f"No pseudopotentials found under {cases}")
    return files


def verify(path, name, expected):
    observed = hashlib.sha256(path.read_bytes()).hexdigest()
    if observed != expected:
        raise ValueError(f"SHA-256 mismatch for {name}. Expected {expected}, got {observed}.")


def fetch(cases, dest, offline):
    files = pinned_files(cases)
    missing = []
    for name, (url, sha) in sorted(files.items()):
        path = dest / name
        if path.exists():
            verify(path, name, sha)
            print(f"Verified existing {name}")
        else:
            missing.append((path, url, sha))
    if offline and missing:
        raise ValueError("Missing with --offline: " + ", ".join(path.name for path, _, _ in missing))
    if missing:
        dest.mkdir(exist_ok=True, parents=True)
    for path, url, sha in missing:
        with NamedTemporaryFile(dir=dest, prefix=f".{path.name}.", delete=False) as output:
            temporary = Path(output.name)
        try:
            with urlopen(url, timeout=60) as response, temporary.open("wb") as output:
                while block := response.read(1024 * 1024):
                    output.write(block)
            verify(temporary, path.name, sha)
            temporary.replace(path)
            print(f"Downloaded and verified {path.name}")
        finally:
            temporary.unlink(missing_ok=True)
    print(f"{len(files)} verified pseudopotentials in {dest}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases", type=Path, default=HERE / "cases", help="directory of case manifests")
    parser.add_argument("--pseudos", type=Path, default=HERE / "pseudos", help="destination UPF directory")
    parser.add_argument("--offline", action="store_true", help="verify all cached files without downloading")
    args = parser.parse_args()
    try:
        fetch(args.cases, args.pseudos, args.offline)
    except (OSError, ValueError, KeyError) as error:
        parser.exit(1, f"{error}\n")


if __name__ == "__main__":
    main()
