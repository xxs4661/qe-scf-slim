"""Check single-invocation benchmark logs and replay their prefixes without future lines.

Run with the v0.4.0 Python source on PYTHONPATH (or its wheel installed).
Uses no scheduler, CLI output or benchmark-side verdict as the outcome reference.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path
from scfopt.diagnostics import diagnose

ITERATION = re.compile(r"^\s*iteration\s*#\s*(\d+)")
ACCURACY = re.compile(r"^\s*estimated\s+scf\s+accuracy\s*[<=]\s*([-+.\dEeDd]+)\s+Ry\b", re.I)
OUTCOME = re.compile(r"^\s*convergence (has been achieved|NOT achieved) (?:in|after)\s*(\d+) iterations?", re.I)
ENERGY = re.compile(r"^\s*!\s*total energy\s*=\s*([-+.\dEeDd]+)\s+Ry", re.I)
THRESHOLD = re.compile(r"^\s*(?:scf )?convergence threshold\s*=\s*([-+.\dEeDd]+)", re.I)
MAGNETIZATION = re.compile(r"^\s*(total|absolute) magnetization\s*=\s*([-+.\dEeDd]+)\s*Bohr mag/cell", re.I)


def measure(text):
    return float(text.replace("D", "E").replace("d", "e"))


def inspect(stdout_path, log_root):
    raw = stdout_path.read_bytes()
    lines = raw.decode("utf-8", errors="replace").splitlines()
    steps = []
    outcomes = []
    evidence = {}
    accuracy_indices = []
    moments = {}
    reported = None
    final_energy = None
    threshold = None
    for number, line in enumerate(lines, 1):
        if match := ITERATION.search(line):
            steps.append(int(match[1]))
        if match := OUTCOME.search(line):
            outcomes.append((match[1].lower(), int(match[2]), number))
        if match := ACCURACY.search(line):
            accuracy_indices.append(number)
            reported = measure(match[1])
        if match := ENERGY.search(line):
            final_energy = measure(match[1])
        if match := THRESHOLD.search(line):
            threshold = measure(match[1])
        if match := MAGNETIZATION.search(line):
            moments[match[1].lower()] = measure(match[2])
        if line.strip() == "JOB DONE.":
            evidence["footer"] = number
    raw_status = "incomplete_or_unrecognized"
    if len(outcomes) == 1:
        marker, marker_steps, number = outcomes[0]
        evidence["outcome"] = number
        if marker == "not achieved":
            raw_status = "unconverged"
        elif evidence.get("footer", 0) > number:
            raw_status = "converged"
    # The panel intentionally exercises single-process, standard electronic SCF.
    # Report any extra/error/ambiguous marker explicitly, rather than assuming success.
    review_lines = [i for i, line in enumerate(lines, 1)
                    if ("error in routine " in line.lower() or "mpi_abort" in line.lower())]
    if review_lines:
        evidence["fatal_lines"] = review_lines
        raw_status = "failed"
    qe = diagnose(lines)
    decision = qe["intervention"]
    discrepancies = []
    if raw_status != qe["status"]:
        discrepancies.append(f"independent={raw_status}; tool={qe['status']}")
    if len(outcomes) > 1:
        discrepancies.append("expected exactly one SCF outcome record in the completed solver run")
    if len(outcomes) == 1 and (not steps or marker_steps != len(steps) or marker_steps != qe["iterations"]):
        discrepancies.append("outcome count, printed iteration records, and parser count disagree")
    if final_energy != qe["energy_ry"] or reported != qe["residual_ry"] or threshold != qe["threshold_ry"]:
        discrepancies.append("independent numerical records differ from parser output")
    cited = {event["line"]: event["text"] for event in qe["evidence"]}
    if any(cited.get(i) != lines[i - 1].strip() for i in decision["evidence_lines"]):
        discrepancies.append("missing or wrong line in terminal intervention evidence")
    alerts = []
    for n in accuracy_indices:
        # Probe the state as of each printed accuracy value. The current run's
        # later footer and energy are deliberately withheld from the classifier.
        snapshot = diagnose(lines[:n])
        recommendation = snapshot["intervention"]
        if recommendation["code"] == "monitor_rebounds":
            alerts.append({"iteration": snapshot["iterations"], "line": n})
        if (recommendation["priority"] == "intervene"
                and (not outcomes or n < outcomes[0][2])):
            discrepancies.append(f"premature terminal intervention at line {n}")
        if any(i > n for i in recommendation["evidence_lines"]):
            discrepancies.append(f"future evidence cited at line {n}")
    return dict(path=str(stdout_path.relative_to(log_root)),
                sha256=hashlib.sha256(raw).hexdigest(), reference_status=raw_status,
                marker_count=len(outcomes), printed_iterations=len(steps), job_done="footer" in evidence,
                final_energy_ry=final_energy, last_accuracy_ry=reported, conv_thr_ry=threshold,
                final_magnetization_bohr_per_cell=moments, terminal_priority=decision["priority"],
                terminal_code=decision["code"], evidence=evidence,
                intervention_evidence_lines=decision["evidence_lines"],
                monitored_snapshots=len(accuracy_indices), rebound_snapshots=alerts,
                discrepancies=discrepancies)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--pattern", default="pw.out")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    logs = sorted(args.root.rglob(args.pattern))
    if not logs:
        parser.error("no logs match the supplied pattern")
    rows = [inspect(path, args.root) for path in logs]
    discrepancies = {r["path"]: r["discrepancies"] for r in rows if r["discrepancies"]}
    args.output.write_text(json.dumps({"logs": rows, "discrepancies": discrepancies}, indent=2) + "\n")
    print(f"{len(rows)} logs; {len(discrepancies)} with discrepancies")
    return int(bool(discrepancies))


if __name__ == "__main__":
    raise SystemExit(main())
