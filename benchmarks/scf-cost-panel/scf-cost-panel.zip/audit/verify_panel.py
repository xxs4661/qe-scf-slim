"""Verify controlled inputs, reference outcomes, log citations and matched solver costs."""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
from verify_logs import inspect

CASES = ("si-diamond", "al-fcc", "na-bcc", "fe-bcc", "mgo-rs", "al111-stress", "na110-slab")
KNOWN = {"si-diamond", "al111-stress"}


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def acceptance(row, timed):
    return (row["reference_status"] == "converged" and row["job_done"]
            and row["final_energy_ry"] is not None and math.isfinite(row["final_energy_ry"])
            and timed.get("returncode") == 0 and not timed.get("timeout", False))


def check_run_fields(row, timed):
    expected = {"accepted": acceptance(row, timed), "status": row["reference_status"],
                "priority": row["terminal_priority"], "code": row["terminal_code"],
                "iterations": row["printed_iterations"] or None, "accuracy_ry": row["last_accuracy_ry"],
                "energy_ry": row["final_energy_ry"], "evidence_lines": row["intervention_evidence_lines"],
                "magnetization_bohr": row["final_magnetization_bohr_per_cell"].get("total")}
    return {field: {"derived": value, "stored": timed[field]} for field, value in expected.items()
            if timed[field] != value}


def normalize_input(text, beta, cap):
    def replace_scalar(text, name, expected):
        pattern = re.compile(rf"\b{name}\s*=\s*([-+.0-9EeDd]+)", re.IGNORECASE)
        matches = pattern.findall(text)
        if len(matches) != 1 or float(matches[0].lower().replace("d", "e")) != expected:
            raise ValueError(f"expected one {name}={expected}, found {matches}")
        return pattern.sub(f"{name}=VALUE", text)
    return replace_scalar(replace_scalar(text, "mixing_beta", beta), "electron_maxstep", cap)


def totals(batch, policy):
    attempts, success, seconds, iterations, manual = 0, 0, 0.0, 0, []
    for case in CASES:
        a = batch[(case, "A")]
        arms = ["A"]
        if policy == "run both full settings":
            arms = ["A", "B"]
        elif policy == "B only":
            arms = ["B"]
        elif policy == "80 from start":
            arms = ["A"] if a["accepted"] else ["E"]
        elif not a["accepted"]:
            if policy == "lower beta on failure":
                arms.append("B")
            if policy == "extend on failure":
                arms.append("E")
            if policy == "frozen triage":
                if a["terminal_code"] == "repeated_rebounds":
                    arms.append("B")
                elif a["terminal_code"] in ("short_iteration_budget", "improving_at_limit"):
                    arms.append("E")
                else:
                    manual.append(case)
        selected = [batch[(case, arm)] for arm in arms]
        attempts += len(selected)
        seconds += sum(r["elapsed_s"] for r in selected)
        iterations += sum(r["printed_iterations"] for r in selected)
        success += int(any(r["accepted"] for r in selected))
    return {"policy": policy, "solver_wall_s": round(seconds, 6), "launches": attempts,
            "accepted": success, "cases": len(CASES), "printed_iterations": iterations, "manual_review": manual}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--panel", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--partial", action="store_true")
    args = parser.parse_args()
    panel = args.panel
    results = panel / "measured"
    issues = []
    rows = {}
    material_declarations = {}
    for case in CASES:
        case_dir = panel / "cases" / case
        if not (case_dir / "case.json").exists() and args.partial:
            continue
        settings = json.loads((case_dir / "case.json").read_text())
        pseudos = settings["pseudopotentials"]
        for pseudo in pseudos:
            if file_hash(panel / "pseudos" / pseudo["file"]) != pseudo["sha256"]:
                issues.append(f"{case}: pseudopotential bytes disagree with declaration")
        reference = normalize_input((case_dir / "base.in").read_text(), .7, 40)
        material_declarations[case] = {"base_sha256": file_hash(case_dir / "base.in"),
                                       "upfs": [p["sha256"] for p in pseudos]}
        for round_number in (1, 2, 3):
            for arm in ("A", "B", "E"):
                run = results / case / f"r{round_number}" / arm
                if not (run / "timing.json").exists():
                    continue
                data = inspect(run / "pw.out", results)
                if data["discrepancies"]:
                    issues.append({data["path"]: data["discrepancies"]})
                timed = json.loads((run / "timing.json").read_text())
                if mismatches := check_run_fields(data, timed):
                    issues.append({data["path"]: mismatches})
                elapsed = timed["elapsed_s"]
                assert elapsed > 0 and math.isfinite(elapsed), str(run)
                try:
                    normalized = normalize_input((run / "pw.in").read_text(), .2 if arm == "B" else .7,
                                                 80 if arm == "E" else 40)
                except ValueError as err:
                    issues.append(f"{case}/{arm}/r{round_number}: {err}")
                    normalized = None
                if normalized != reference:
                    issues.append(f"{case}/{arm}/r{round_number}: input differs beyond declared knobs")
                if data["conv_thr_ry"] != 1e-8:
                    issues.append(f"{case}/{arm}/r{round_number}: printed threshold {data['conv_thr_ry']}")
                data.update(case=case, arm=arm, round=round_number, accepted=acceptance(data, timed),
                            elapsed_s=elapsed, returncode=timed.get("returncode"))
                rows[case, round_number, arm] = data
    for case in CASES:
        baseline_fails = any(not v["accepted"] for (name, _, arm),v in rows.items()
                             if name == case and arm == "A")
        expected = ["A", "B", "E"] if baseline_fails else ["A", "B"]
        if not args.partial:
            for i in range(1, 4):
                for arm in expected:
                    if (case, i, arm) not in rows:
                        issues.append(f"missing {case}/r{i}/{arm}")
    by_case = []
    for case in CASES:
        for arm in ("A","B","E"):
            group = [r for r in rows.values() if r["case"] == case and r["arm"] == arm]
            if not group:
                continue
            by_case.append({"case": case, "arm": arm, "n": len(group),
                            "outcomes": dict(Counter(r["reference_status"] for r in group)),
                            "terminal_codes": dict(Counter(r["terminal_code"] for r in group)),
                            "first_rebound_review_per_run": [
                                next((p["iteration"] for p in r["rebound_snapshots"]),None) for r in group],
                            "energy_ry": [r["final_energy_ry"] for r in group],
                            "magnetization": [r["final_magnetization_bohr_per_cell"] for r in group]})
    physical_differences = {}
    for case in CASES:
        accepted = [r for r in rows.values() if r["case"] == case and r["accepted"]]
        energies = [r["final_energy_ry"] for r in accepted]
        moments = [r["final_magnetization_bohr_per_cell"]["total"] for r in accepted
                   if "total" in r["final_magnetization_bohr_per_cell"]]
        if accepted:
            physical_differences[case] = dict(accepted=len(accepted), arms=sorted({r["arm"] for r in accepted}),
                                              energy_range_ry=max(energies)-min(energies),
                                              total_moment_range_bohr=[min(moments),max(moments)] if moments else None)
    costs = []
    if not args.partial and not issues:
        for i in range(1,4):
            batch = {(case,arm): r for (case,rep,arm), r in rows.items() if rep == i}
            for policy in ("A only","B only","80 from start","lower beta on failure","extend on failure",
                           "frozen triage","run both full settings"):
                costs.append(dict(round=i, **totals(batch,policy)))
    def counts(records):
        return dict(Counter(("accepted" if r["accepted"] else "failed") +
                            ("_with_rebound_review" if r["rebound_snapshots"] else "_no_rebound_review")
                            for r in records))
    prefixes = {label:counts(r for r in rows.values() if r["arm"] == "A"
                             and (label == "all" or r["case"] not in KNOWN))
                for label in ("all", "holdout_only")}
    all_ab = counts(r for r in rows.values() if r["arm"] in ("A","B"))
    out = {"scope":"Physical panel only. Rebound review is a non-binding look at current output; credit zero compute savings.",
           "input_sources":material_declarations,"n_logs":len(rows),"status_mismatches":issues,
           "by_case":by_case,"physical_differences":physical_differences,
           "baseline_prefix_alerts":prefixes,"A_B_prefix_alerts":all_ab,"costs_excluding_annotation":costs,
           "logs":list(rows.values())}
    args.output.write_text(json.dumps(out, indent=2)+"\n")
    print(json.dumps({"logs":len(rows),"issues":issues,"prefixes":prefixes}))
    return int(bool(issues))

if __name__ == "__main__":
    raise SystemExit(main())
