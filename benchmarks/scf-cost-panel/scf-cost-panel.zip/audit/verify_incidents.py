"""Audit the known injected faults separately from the seven physical outcomes."""
import argparse
import json
from pathlib import Path
from verify_logs import inspect
from verify_panel import acceptance, check_run_fields, normalize_input


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--panel", required=True, type=Path)
    p.add_argument("--output", required=True, type=Path)
    args = p.parse_args()
    measured = args.panel / "measured"
    episodes = []
    issues = []
    cases = [("si-short-budget", "si-diamond", "short_iteration_budget", 2),
             ("fe-missing-upf", "fe-bcc", "pseudopotential_error", 40)]
    for problem, source, expected_code, cap in cases:
        reference = (args.panel / "cases" / source / "base.in").read_text()
        if problem == "fe-missing-upf":
            reference = reference.replace("Fe.pbe-spn-kjpaw_psl.1.0.0.UPF", "Fe_missing_benchmark.UPF")
        for rep in range(1, 4):
            launches = {}
            for arm, beta in (("A", .7), ("B", .2)):
                folder = measured / problem / f"r{rep}" / arm
                data = inspect(folder / "pw.out", measured)
                timing = json.loads((folder / "timing.json").read_text())
                actual = normalize_input((folder / "pw.in").read_text(), beta, cap)
                if (actual != normalize_input(reference, .7, 40)
                        or acceptance(data, timing) or data["terminal_code"] != expected_code
                        or data["discrepancies"] or check_run_fields(data, timing)):
                    issues.append(str(folder))
                launches[arm] = dict(path=data["path"], sha256=data["sha256"],
                                     time_s=timing["elapsed_s"], status=data["reference_status"],
                                     decision=data["terminal_code"], evidence=data["intervention_evidence_lines"])
            corrected = measured / source / f"r{rep}" / "A"
            timing = json.loads((corrected / "timing.json").read_text())
            if not acceptance(inspect(corrected / "pw.out", measured), timing):
                issues.append(str(corrected))
            targeted = launches["A"]["time_s"] + timing["elapsed_s"]
            episodes.append(dict(incident=problem, round=rep, launches=launches,
                                 corrected_A_from=str(corrected.relative_to(measured)),
                                 targeted_s_excluding_cli=targeted,
                                 blind_then_repair_s_excluding_cli=targeted + launches["B"]["time_s"]))
    args.output.write_text(json.dumps({"episodes": episodes, "issues": issues}, indent=2)+"\n")
    print(json.dumps({"episodes":len(episodes), "issues":issues}))
    return int(bool(issues))


if __name__ == "__main__":
    raise SystemExit(main())
