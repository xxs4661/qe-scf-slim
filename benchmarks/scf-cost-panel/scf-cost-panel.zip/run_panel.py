"""Run the fixed panel sequentially. Supply a local QE 7.5 pw.x, UPFs and a fresh output path."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time

from scfopt.diagnostics import diagnose

HERE = Path(__file__).resolve().parent
CASES = ["na-bcc", "al-fcc", "fe-bcc", "si-diamond", "al111-stress", "mgo-rs", "na110-slab"]


def updated(text, old, new):
    if text.count(old) != 1:
        raise ValueError(f"Expected one {old!r} in input")
    return text.replace(old, new)


def run_case(case, rep, arm, args):
    folder = args.outdir / case / f"r{rep}" / arm
    folder.mkdir(parents=True)
    source = {"si-short-budget": "si-diamond", "fe-missing-upf": "fe-bcc"}.get(case, case)
    input_text = (HERE / "cases" / source / "base.in").read_text()
    if case == "fe-missing-upf":
        input_text = updated(input_text, "Fe.pbe-spn-kjpaw_psl.1.0.0.UPF", "Fe_missing_benchmark.UPF")
    steps = 2 if case == "si-short-budget" else 40
    if arm == "E":
        steps *= 2
    input_text = updated(input_text, "electron_maxstep=40", f"electron_maxstep={steps}")
    beta = 0.2 if arm == "B" else 0.7
    input_text = updated(input_text, "mixing_beta=0.70", f"mixing_beta={beta:.2f}")
    (folder / "pw.in").write_text(input_text)
    (folder / "pseudos").symlink_to(args.pseudos, target_is_directory=True)
    env = dict(os.environ, OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
               JULIA_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1", MKL_NUM_THREADS="1")
    with (folder / "pw.out").open("wb") as stdout, (folder / "pw.err").open("wb") as stderr:
        start = time.monotonic()
        proc = subprocess.Popen([args.pw, "-in", "pw.in"], cwd=folder, env=env, stdout=stdout,
                                stderr=stderr, start_new_session=True)
        timeout = False
        try:
            proc.wait(timeout=360)
        except subprocess.TimeoutExpired:
            timeout = True
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait()
        elapsed = time.monotonic() - start
    raw = (folder / "pw.out").read_text(errors="replace")
    report = diagnose(raw.splitlines())
    moment = re.findall(r"total magnetization\s*=\s*([-+.\d]+)\s+Bohr mag/cell", raw)
    ok = bool(not timeout and proc.returncode == 0 and report["status"] == "converged" and
              report["energy_ry"] is not None and report["job_done"])
    record = dict(case=case, round=rep, arm=arm, beta=beta, maxstep=steps, elapsed_s=elapsed,
                  returncode=proc.returncode, timeout=timeout, accepted=ok, status=report["status"],
                  code=report["intervention"]["code"], priority=report["intervention"]["priority"],
                  iterations=report["iterations"], accuracy_ry=report["residual_ry"], energy_ry=report["energy_ry"],
                  magnetization_bohr=float(moment[-1]) if moment else None,
                  evidence_lines=report["intervention"]["evidence_lines"])
    (folder / "timing.json").write_text(json.dumps(record, indent=2) + "\n")
    print(f"{case:16} round {rep} {arm} {elapsed:7.2f}s  {record['code']}  {record['iterations']} steps", flush=True)
    return record


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--pw", default="pw.x")
    p.add_argument("--pseudos", required=True, type=Path)
    p.add_argument("--outdir", required=True, type=Path)
    args = p.parse_args()
    args.pw = shutil.which(args.pw)
    if args.pw is None:
        p.error("pw.x not found")
    args.pw = str(Path(args.pw).absolute())
    args.pseudos = args.pseudos.resolve()
    for case in CASES:
        source = HERE / "cases" / case
        meta = json.loads((source / "case.json").read_text())
        for pseudo in meta["pseudopotentials"]:
            path = args.pseudos / (pseudo.get("file") or pseudo["filename"])
            if hashlib.sha256(path.read_bytes()).hexdigest() != pseudo["sha256"]:
                p.error(f"UPF checksum failed for {path}")
    args.outdir = args.outdir.resolve()
    args.outdir.mkdir(parents=True, exist_ok=False)
    extension = set()
    for rep in (1, 2, 3):
        offset = ((rep - 1) * 3) % len(CASES)
        for case in CASES[offset:] + CASES[:offset]:
            for arm in (("B", "A") if rep == 2 else ("A", "B")):
                record = run_case(case, rep, arm, args)
                if arm == "A" and not record["accepted"]:
                    extension.add(case)
    for rep in (1, 2, 3):
        for case in sorted(extension):
            run_case(case, rep, "E", args)
        for case in ("si-short-budget", "fe-missing-upf"):
            for arm in (("B", "A") if rep == 2 else ("A", "B")):
                run_case(case, rep, arm, args)


if __name__ == "__main__":
    main()
