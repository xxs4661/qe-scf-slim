"""Time the frozen scf-slim CLI against completed panel logs. Run after the solver exits."""
import argparse
from collections import Counter
import json
from pathlib import Path
import shutil
import statistics
import subprocess
import time


CASES = ("na-bcc", "al-fcc", "fe-bcc", "si-diamond", "al111-stress", "mgo-rs", "na110-slab")
RETRY = {"repeated_rebounds": "B", "improving_at_limit": "E", "short_iteration_budget": "E"}
# Each known repair reuses its underlying material's normal A in the same round.
INCIDENTS = {
    "si-short-budget": ("short_iteration_budget", "si-diamond"),
    "fe-missing-upf": ("pseudopotential_error", "fe-bcc"),
}
PRIORITIES = ("intervene", "review", "read_error", "none")
FLAGS = ["triage", "--json", "--check"]


def load_run(root, case, rep, arm):
    path = Path(case, f"r{rep}", arm, "pw.out")
    data = json.loads((root / path.with_name("timing.json")).read_text())
    if (data["case"], data["round"], data["arm"]) != (case, rep, arm):
        raise ValueError(f"Wrong solver metadata at {path}")
    if not (root / path).is_file():
        raise FileNotFoundError(root / path)
    return {**data, "path": str(path)}


def run_batch(runs):
    # Explicit file arguments only. An ordered dictionary keeps duplicated paths out.
    paths = list(dict.fromkeys(run["path"] for run in runs))
    return {"paths": paths, "samples_s": [], "decisions": []}


def round_plan(root, rep):
    primary = [load_run(root, case, rep, "A") for case in CASES]
    retry = []
    for run in primary:
        arm = RETRY.get(run["code"])
        if not run["accepted"] and run["priority"] == "intervene" and arm:
            retry.append(load_run(root, run["case"], rep, arm))
    incident = [load_run(root, case, rep, "A") for case in INCIDENTS]
    repair = []
    for run in incident:
        code, case = INCIDENTS[run["case"]]
        if not run["accepted"] and run["priority"] == "intervene" and run["code"] == code:
            repair.append(load_run(root, case, rep, "A"))

    groups = {"primary": primary, "retry": retry, "incident": incident, "repair": repair}
    expected = {run["path"]: run for runs in groups.values() for run in runs}
    batches = {name: run_batch(runs) for name, runs in groups.items()}
    # Individual-latency samples are supplementary. Never add them to policy costs.
    singles = [run_batch([run]) for run in expected.values()]
    return {"round": rep, **batches, "single_log": singles}, expected


def check_report(stdout, returncode, batch, expected):
    report = json.loads(stdout)
    if report["schema_version"] != 1:
        raise ValueError("Unsupported CLI report schema")
    paths = batch["paths"]
    rows = {run["path"]: run for run in report["runs"]}
    if len(report["runs"]) != len(paths) or set(rows) != set(paths):
        raise ValueError(f"CLI returned duplicate, missing or unexpected paths for {paths}")
    decisions = []
    for path in paths:
        row = rows[path]
        ref = expected[path]
        if row["status"] == "read_error":
            raise ValueError(f"CLI could not read {path}: {row.get('error')}")
        action = row["intervention"]
        observed = (row["status"], action["priority"], action["code"], action["evidence_lines"])
        saved = (ref["status"], ref["priority"], ref["code"], ref["evidence_lines"])
        if observed != saved:
            raise ValueError(f"CLI disagrees with the solver record at {path}: {observed} vs {saved}")
        accepted = ref["accepted"] and action["priority"] == "none"
        decisions.append({"path": path, "case": ref["case"], "arm": ref["arm"],
                          "status": row["status"], **action, "solver_accepted": ref["accepted"],
                          "accepted_without_review": accepted})
    counts = Counter(row["priority"] for row in decisions)
    if report["counts"] != {k: counts[k] for k in PRIORITIES}:
        raise ValueError("CLI priority counts do not match the returned decisions")
    if returncode != int(bool(counts["intervene"] or counts["review"])):
        raise ValueError(f"Unexpected --check exit code {returncode} for {paths}")
    if batch["decisions"] and batch["decisions"] != decisions:
        raise ValueError(f"CLI output changed across timing samples for {paths}")
    batch.update(decisions=decisions, check_exit=returncode)


def measure(cli, root, batch, expected):
    started = time.perf_counter_ns()
    proc = subprocess.run([cli, *FLAGS, *batch["paths"]], cwd=root, capture_output=True)
    elapsed = (time.perf_counter_ns() - started) / 1e9
    if proc.returncode not in (0, 1):
        raise RuntimeError(f"CLI exited {proc.returncode}: {proc.stderr.decode(errors='replace')}")
    check_report(proc.stdout, proc.returncode, batch, expected)
    batch["samples_s"].append(elapsed)


def summarize(batch):
    samples = batch["samples_s"]
    batch.update(median_s=statistics.median(samples) if samples else 0.0,
                 min_s=min(samples, default=0.0), max_s=max(samples, default=0.0))
    batch["argv"] = ["scf-slim", *FLAGS, *batch["paths"]] if samples else []
    if not samples:
        batch["check_exit"] = None


def outcomes(first, second, incident=False):
    seen = {run["case"]: run for run in second["decisions"]}
    rows = []
    for run in first["decisions"]:
        follow = seen.get(INCIDENTS[run["case"]][1] if incident else run["case"])
        final = follow or run
        rows.append({"case": run["case"], "first_code": run["code"],
                     "followup_path": follow["path"] if follow else None,
                     "final_code": final["code"], "final_priority": final["priority"],
                     "solver_accepted": final["solver_accepted"],
                     "disposition": "accept" if final["accepted_without_review"] else "manual_review"})
    return rows


def collect(cli, root, repeats):
    plans = [round_plan(root, rep) for rep in (1, 2, 3)]
    version = subprocess.run([cli, "--version"], cwd=root, capture_output=True, text=True,
                             check=True).stdout.strip()
    if version != "scf-slim 0.4.0":
        raise ValueError(f"Expected scf-slim 0.4.0, got {version!r}")
    jobs = []
    for groups, expected in plans:
        batches = [groups[key] for key in ("primary", "retry", "incident", "repair")]
        batches += groups["single_log"]
        jobs.extend((batch, expected) for batch in batches)
    for index in range(repeats):
        # Reverse the complete sequence each pass so fixed case/group order does not
        # systematically favor one group within each forward/reverse pair.
        scheduled = jobs if index % 2 == 0 else reversed(jobs)
        for batch, expected in scheduled:
            if batch["paths"]:
                measure(cli, root, batch, expected)
    for batch, _ in jobs:
        summarize(batch)
    for groups, _ in plans:
        groups["primary_outcomes"] = outcomes(groups["primary"], groups["retry"])
        groups["incident_outcomes"] = outcomes(groups["incident"], groups["repair"], incident=True)
    return {"schema_version": 1, "cli_version": version, "repeats": repeats,
            "cwd": "solver-results directory containing the case folders",
            "clock": "perf_counter_ns; elapsed child process through captured stdout/stderr; includes startup",
            "order": "Each pass visits all rounds, batches and single logs; even passes reverse the entire sequence.",
            "cache": "Repeated reads of existing logs, OS caches not cleared. CLI --version checked first.",
            "argv_note": "Replace argv[0] with --cli; paths are relative to cwd. An empty batch has zero cost.",
            "rounds": [groups for groups, _ in plans]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cli", required=True, help="frozen scf-slim v0.4.0 executable")
    parser.add_argument("--results", required=True, type=Path,
                        help="panel root containing measured/, or the directory of case logs")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--repeats", type=int, default=8, help="at least 7; default 8 balances order")
    args = parser.parse_args()
    if args.repeats < 7:
        parser.error("--repeats must be at least 7")
    resolved_cli = shutil.which(args.cli)
    if not resolved_cli:
        parser.error(f"Executable not found: {args.cli}")
    root = args.results.resolve()
    if (root / "measured").is_dir():
        root = root / "measured"
    data = collect(str(Path(resolved_cli).absolute()), root, args.repeats)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
